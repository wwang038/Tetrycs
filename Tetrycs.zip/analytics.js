(function (w, d, s, l, i) {
    w[l] = w[l] || [];
    w[l].push({ "gtm.start": new Date().getTime(), event: "gtm.js" });
    var f = d.getElementsByTagName(s)[0],
        j = d.createElement(s),
        dl = l != "dataLayer" ? "&l=" + l : "";
    j.async = true;
    j.src = "https://www.googletagmanager.com/gtm.js?id=" + i + dl;
    f.parentNode.insertBefore(j, f);
})(window, document, "script", "dataLayer", "GTM-NJ8RXZD");

(function (i, s, o, g, r, a, m) {
    i["GoogleAnalyticsObject"] = r;
    (i[r] =
        i[r] ||
        function () {
            (i[r].q = i[r].q || []).push(arguments);
        }),
        (i[r].l = 1 * new Date());
    (a = s.createElement(o)), (m = s.getElementsByTagName(o)[0]);
    a.async = 1;
    a.src = g;
    m.parentNode.insertBefore(a, m);
})(
    window,
    document,
    "script",
    "https://google-analytics.com/analytics.js",
    "ga"
);

ga("create", "UA-210471096-1", "auto");

// https://stackoverflow.com/questions/48560583/add-google-analytics-to-a-chrome-extension
ga("set", "checkProtocolTask", null);

if (window.location.href.indexOf("chrome-extension://") === 0) {
    let version = "popup-version-error";

    try {
        version = chrome.runtime.getManifest().version;
    } catch (_) {}

    ga("send", "pageview", `/popup@${version}`);
} else {
    ga("send", "pageView", "/web");
}
